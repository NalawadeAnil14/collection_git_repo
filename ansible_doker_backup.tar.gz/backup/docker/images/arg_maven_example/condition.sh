#!/bin/bash

if [ "$1" == "1" ]; then
	MAVEN_VERSION="3.9.9-eclipse-temurin-11"
elif [ "$1" == "2" ]; then
        MAVEN_VERSION="latest"
else
        echo "Invalid choice"
        exit 1
fi

docker build --build-arg VERSION_CHOICE=$MAVEN_VERSION -t mavenimage .
