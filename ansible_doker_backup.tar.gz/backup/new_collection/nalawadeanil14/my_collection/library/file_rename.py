#!/usr/bin/python

import json
from ansible.module_utils.basic import AnsibleModule
import os

DOCUMENTATION = '''
---
module: filerename
short_description: This module rename file on remote server
description: 
  - This module is used to rename file name that file provided in path option.

options: 
  src: 
    description:
      - Here you can provide path of your file
    required: true
    type: str

  dest:
    description:
      - The new path to rename
    required: true  
    type: str

author: Anil Nalawade
'''

EXAMPLES = '''
# Rename a file
- name: Rename a file
  nalawadeanil14.my_collection.filerename:
    src: /path/to/old_file.txt
    dest: /path/to/new_file.txt
'''

def main():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(required=True, type="str"),
            dest=dict(required=True, type="str"),
        ),

        support_check_mode=True
    )

    src = module.params["src"]
    dest = module.params["dest"]


    if not os.path.exists(src):
        module.fail_json(msg=f"Source file '{src}' does not exist")

    if os.path.exists(dest):
        module.exit_json(changed=False, msg=f"Destination file '{dest}' already exist")
    
    if module.check_mode:
        module.exit_json(changed=True, msg=f"File would be renamed from '{src}' to '{dest}'.")
        
    try:
        os.rename(src, dest)
        module.exit_json(changed=True, msg=f"File renamed from '{src}' to '{dest}'.")

    except Exception as e:
        module.fail_json(msg=f"Failed to rename file: {e}")


if __name__ == "__main__":
    main()
