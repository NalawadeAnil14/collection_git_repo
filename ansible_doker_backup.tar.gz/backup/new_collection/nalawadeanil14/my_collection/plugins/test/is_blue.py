DOCUMENTATION = '''
---
test: blue
short_description: To check provided color form 
description: 
  - This plugin is used to check given form of color is in the form of blue or not.(is_blue) 
author: Anil Nalawade  
'''

EXAMPLES = '''
# To check blue form
var: 
  my_color_choice: blue (diffrent choices like : Blue, #00ffff, #0ff, rgb(0%,0%,100%))

tasks: 
  - name: Check form of color
    assert: 
      that: my_color_choice is blue
'''

def is_blue(string):
    blue_form = [ "blue",
                   "#0000ff",
                   "#0ff",
                   "rgb(0%,0%,100%)" 
                 ]

    return string in blue_form

class TestModule(object):
    
    def tests(self):
        return {
              'blue' : is_blue
            }
