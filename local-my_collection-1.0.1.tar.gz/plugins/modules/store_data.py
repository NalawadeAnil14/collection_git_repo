#!/usr/bin/python
import json
from ansible.module_utils.basic import AnsibleModule
import sys

def main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type="str"),
                age=dict(required=True, type="int"),
                )
            )

    name = module.params["name"]
    age = module.params["age"]

    data = dict(output="Your data has stored successfully")

    try:
         with open("./userdata.txt","w") as file:
            file.write(f"{name},{age}\n")
      
         module.exit_json(changed=True,success=data,msg=data)
        
    except Exception as e:
         module.fail_json(msg=f"Error: {str(e)}")

if __name__ == "__main__":
    main()
        
