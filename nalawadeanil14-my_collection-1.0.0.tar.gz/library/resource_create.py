#!/usr/bin/python3

from ansible.module_utils.basic import AnsibleModule


def main():
    module_argument = dict(
        name=dict(type="str", required=True),
        state=dict(type="str", choices=["present", "absent"], default="present"),
    )

    module = AnsibleModule(argument_spec=module_argument, supports_check_mode=True)

    name = module.params["name"]
    state = module.params["state"]

    result = dict(changed=False, message="")

    if state == "present":
        result["changed"] = True
        result["message"] = f"Resource '{name}' created"
    elif state == "absent":
        result["changed"] = True
        result["message"] = f"Resource '{name}' deleted"

    module.exit_json(**result)


if __name__ == "__main__":
    main()
