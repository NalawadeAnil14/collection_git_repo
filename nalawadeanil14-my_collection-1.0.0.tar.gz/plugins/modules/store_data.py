#!/usr/bin/python3

from ansible.module_utils.basic import AnsibleModule

DOCUMENTATION = '''
---
module: store_data
short_desciption: This module is used to store userdata in file
description :
  - User provided data using ansible module option get stored in text file.

options:
  name:
    description:
      - Name of user that you want to store
    required: true
    type: str

  age:
    description:
      -  Age of user to store in file
    required: true
    type: int

author: Anil Nalawade
'''

EXAMPLES = '''
# To store user data
- name: Store user data
  nalawadeanil14.my_collection.store_data:
    name: Anil
    age: 28
'''

def main():

    module_args = dict(
        name=dict(type="str", required=True), age=dict(type="int", required=True)
    )

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    name = module.params["name"]
    age = module.params["age"]

    file_path = "/tmp/userdata.txt"
    new_entry = f"User with name {name} and age {age}\n"

    result = dict(changed=False, message="")

    if module.check_mode:
        if not file_exists(file_path) or not data_exists(file_path, new_entry):
            result["changed"] = True
        module.exit_json(**result)

    try:
        if file_exists(file_path):
            if data_exists(file_path, new_entry):
                result["message"] = "No changes made, data already present"
            else:
                with open(file_path, "a") as file:
                    file.write(new_entry)
                result["changed"] = True
                result["message"] = "Data added to file."

        else:
            with open(file_path, "w") as file:
                file.write(new_entry)

            result["changed"] = True
            result["message"] = "File created and data added to file."

        module.exit_json(**result)

    except Exception as e:
        module.fail_json(f"Failed to add data because: {str(e)}")


def file_exists(file_path):
    try:
        with open(file_path, "r"):
            return True
    except FileNotFoundError:
        return False


def data_exists(file_path, data):
    try:
        with open(file_path, "r") as file:
            for line in file:
                if line.strip() == data.strip():
                    return True
        return False
    except FileNotFoundError:
        return False


if __name__ == "__main__":
    main()
