#!/usr/bin/python

import json
from ansible.module_utils.basic import AnsibleModule
import os


def main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type="str"),
            rename=dict(required=True, type="str"),
        )
    )

    path = module.params["path"]
    rename = module.params["rename"]

    file_name = os.path.basename(path)

    data = dict(
        output="your file has renamed successfully",
    )

    try:
        if os.path.exists(file_name):

            check_file = os.path.isfile(file_name)
            if check_file:
                os.rename(file_name, rename)
                module.exit_json(changed=True, success=data, msg=data)
            else:
                module.exit_json(changed=True, success=data, msg=data)
        else:
            module.exit_json(msg="File is not exists")

    except Exception as e:
        module.fail_json(msg="error")


if __name__ == "__main__":
    main()
