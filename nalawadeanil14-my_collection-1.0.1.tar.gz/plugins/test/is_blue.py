def is_blue(string):
    blue_form = [ "blue",
                   "#0000ff",
                   "#0ff",
                   "rgb(0%,0%,100%)" 
                 ]

    return string in blue_form

class TestModule(object):
    

    def tests(self):
        return {
              'blue' : is_blue
            }
