#!/usr/bin/python
import json
from ansible.module_utils.basic import AnsibleModule
import sys

DOCUMENTATION = '''
---
module: store_data
short_desciption: This module is used to store userdata in file
description : 
  - User provided data using ansible module option get stored in text file.

options: 
  name:
    description: 
      - Name of user that you want to store
    required: true
    type: str

  age:
    description: 
      -  Age of user to store in file
    required: true
    type: int
    
author: Anil Nalawade
'''

EXAMPLES = '''
# To store user data
- name: Store user data 
  nalawadeanil14.my_collection.store_data:
    name: Anil
    age: 28
'''


def main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(required=True, type="str"),
                age=dict(required=True, type="int"),
                )
            )

    name = module.params["name"]
    age = module.params["age"]

    data = dict(output="Your data has stored successfully")

    try:
         with open("./userdata.txt","w") as file:
            file.write(f"{name},{age}\n")
      
         module.exit_json(changed=True,success=data,msg=data)
        
    except Exception as e:
         module.fail_json(msg=f"Error: {str(e)}")

if __name__ == "__main__":
    main()
        
